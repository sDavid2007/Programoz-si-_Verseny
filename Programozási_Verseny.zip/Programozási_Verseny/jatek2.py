import random
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

class Epulet:
    """Épület objektum."""
    def __init__(self, s):
        """Épület létrehozása."""
        sor = s.split(";")
        if len(sor) != 6:
            raise ValueError(f"Hibás adat az épület létrehozásához: {s}")
        self.azonosito = int(sor[0])
        self.nev = sor[1]
        self.tipus = sor[2]
        self.epeteseve = sor[3]
        self.terulet = int(sor[4])
        self.allapot = int(sor[5])

    def __str__(self):
        """Épület szöveges reprezentációja."""
        return f"{self.azonosito};{self.nev};{self.tipus};{self.epeteseve};{self.terulet};{self.allapot}"

epuletek = []
with open("epuletek.csv", "r", encoding="utf-8") as f:
    for i in f:
        epuletek.append(Epulet(i.strip()))

class Szolgaltatas:
    """Szolgáltatás objektum."""
    def __init__(self, s):
        """Szolgáltatás létrehozása."""
        sor = s.split(";")
        self.azonosito = int(sor[0])
        self.nev = sor[1]
        self.tipus = sor[2]
        self.epuletid = int(sor[3])
        self.havi_koltseg = int(sor[4])

szolgaltatasok = []
with open("szolgaltatasok.csv", "r", encoding="utf-8") as f:
    for i in f:
        szolgaltatasok.append(Szolgaltatas(i.strip()))

class Projekt:
    """Projekt objektum."""
    def __init__(self, s):
        """Projekt létrehozása."""
        sor = s.split(";")
        self.azonosito = int(sor[0])
        self.nev = sor[1]
        self.koltseg = int(sor[2])
        self.kezdo_d = datetime.strptime(sor[3], "%Y.%m.%d")
        self.befejezo_d = datetime.strptime(sor[4], "%Y.%m.%d")
        self.tipus = sor[5].strip().lower() if len(sor) > 5 and sor[5].strip() else "ismeretlen"
        self.terulet = 0  # Hozzáadtuk a terület attribútumot

projektek = []
jelenlegi_datum = datetime.now()

with open("projekt.csv", "r", encoding="utf-8") as f:
    for i in f:
        projekt = Projekt(i.strip())
        if projekt.befejezo_d > jelenlegi_datum:
            projektek.append(projekt)

print("Aktív projektek a játék indításakor:")
for projekt in projektek:
    print(f"- {projekt.nev}, befejező dátum: {projekt.befejezo_d.strftime('%Y.%m.%d')}")

with open("projektlista.csv", "w", encoding="utf-8") as f:
    f.write("Projekt_azonosito, nev, koltseg, kezdo_d, befejezo_d, erintett_epuletek\n")
    for projekt in projektek:
        erintett_epuletek = "{}" # Alapértelmezett érték beállítása
        if "Karbantartás" in projekt.nev:
            epulet_nev = projekt.nev.replace("Karbantartás - ", "").strip()
            epulet = next((e for e in epuletek if e.nev.strip() == epulet_nev), None)
            if epulet:
                erintett_epuletek = f"{{{epulet.azonosito}}}"
        f.write(f"{projekt.azonosito}, {projekt.nev}, {projekt.koltseg}, "
                f"{projekt.kezdo_d.strftime('%Y-%m-%d')}, {projekt.befejezo_d.strftime('%Y-%m-%d')}, {erintett_epuletek}\n")

def uj_epulet_epitese(projekt_nev, koltseg, idotartam_honap, tipus, terulet, aktualis_datum):
    """Új épület építése."""
    global projektek
    uj_azonosito = len(projektek) + 1
    kezdo_datum = aktualis_datum
    befejezo_datum = kezdo_datum + relativedelta(months=idotartam_honap)
    projekt = Projekt(f"{uj_azonosito};{projekt_nev};{koltseg};{kezdo_datum.strftime('%Y.%m.%d')};{befejezo_datum.strftime('%Y.%m.%d')};{tipus}")
    projekt.terulet = terulet # A terület attribútum beállítása
    projektek.append(projekt)
    print(f"Új projekt indult: {projekt_nev}, költség: {koltseg}, típus: {tipus}, terület: {terulet} m².")
    print(f"A projekt várhatóan elkészül: {befejezo_datum.strftime('%Y.%m.%d')}.")
    return projekt

def karbantartas(epulet_id, koltseg, kezdo_datum, befejezo_datum):
    """Meglévő épület karbantartása."""
    global projektek, epuletek
    epulet = next((e for e in epuletek if e.azonosito == epulet_id), None)
    if epulet:
        javitasi_pont = 5 - epulet.allapot
        if javitasi_pont <= 0:
            print(f"Az épület ({epulet.nev}) már maximális állapotban van.")
            return

        koltseg = javitasi_pont * 5000
        idotartam_honap = javitasi_pont
        befejezo_datum = kezdo_datum + relativedelta(months=idotartam_honap)

        uj_azonosito = len(projektek) + 1
        projekt = Projekt(f"{uj_azonosito};Karbantartás - {epulet.nev};{koltseg};"
                                    f"{kezdo_datum.strftime('%Y.%m.%d')};{befejezo_datum.strftime('%Y.%m.%d')};karbantartás")
        projektek.append(projekt)

        print(f"Karbantartási projekt indult: {epulet.nev}, költség: {koltseg} Ft, "
              f"várható befejezés: {befejezo_datum.strftime('%Y.%m.%d')}.")
    else:
        print("Hiba: Nem található az épület azonosító alapján.")

def uj_szolgaltatas_bevezetese(nev, epuletid, havi_koltseg, elegedettseg):
    """Új szolgáltatás bevezetése."""
    global szolgaltatasok
    epulet = next((e for e in epuletek if e.azonosito == epuletid), None)
    if not epulet:
        print("Hiba: Nem található az épület azonosító alapján.")
        return elegedettseg

    elfogadott_tipusok = ["egészségügy", "oktatás", "művelődés", "szórakoztatás", "egyéb"]
    while True:
        tipus = input("Adja meg a szolgáltatás típusát (Egészségügy, Oktatás, Művelődés, Szórakoztatás, Egyéb): ").strip().lower()
        if tipus in elfogadott_tipusok:
            tipus = tipus.capitalize()
            break
        print("Hiba: Csak az alábbi típusok adhatók meg: Egészségügy, Oktatás, Művelődés, Szórakoztatás, Egyéb.")

    uj_azonosito = len(szolgaltatasok) + 1
    szolgaltatas = Szolgaltatas(f"{uj_azonosito};{nev};{tipus};{epuletid};{havi_koltseg}")
    szolgaltatasok.append(szolgaltatas)
    elegedettseg += 5
    print(f"Új szolgáltatás bevezetve: {nev}, típus: {tipus}, havi költség: {havi_koltseg}, épület: {epulet.nev}, elégedettség nőtt: {elegedettseg}%")
    return elegedettseg

def szolgaltatas_megszuntetese(elegedettseg):
    """Szolgáltatás megszüntetése."""
    global szolgaltatasok
    while True:
        listaz_szolgaltatasok()
        try:
            szolgaltatas_id = int(input("Adja meg a megszüntetendő szolgáltatás azonosítóját: "))
            szolgaltatas = next((s for s in szolgaltatasok if s.azonosito == szolgaltatas_id), None)
            if szolgaltatas:
                szolgaltatasok.remove(szolgaltatas)
                print(f"Szolgáltatás megszüntetve: {szolgaltatas.nev}")
                elegedettseg -= 5
                print(f"Elégedettség csökkent: -5%. Jelenlegi elégedettség: {elegedettseg}%.")
                return elegedettseg
            else:
                print("Hiba: Nem található a szolgáltatás azonosító alapján. Próbálja újra.")
        except ValueError:
            print("Hiba: Érvénytelen azonosító. Próbálja újra.")

def listaz_szolgaltatasok_epulethez(epuletid):
    """Szolgáltatások listázása épülethez."""
    kapcsolodo_szolgaltatasok = [s for s in szolgaltatasok if s.epuletid == epuletid]
    if kapcsolodo_szolgaltatasok:
        print(f"Szolgáltatások az épülethez (ID: {epuletid}):")
        for szolgaltatas in kapcsolodo_szolgaltatasok:
            print(f"- {szolgaltatas.nev}, havi költség: {szolgaltatas.havi_koltseg}")
    else:
        print(f"Nincs szolgáltatás az épülethez (ID: {epuletid}).")

def listaz_szolgaltatasok():
    """Szolgáltatások listázása."""
    if not szolgaltatasok:
        print("Nincsenek elérhető szolgáltatások.")
        return

    print("\nSzolgáltatások és költségeik:")
    for szolgaltatas in szolgaltatasok:
        print(f"ID: {szolgaltatas.azonosito}, Név: {szolgaltatas.nev} (Épület ID: {szolgaltatas.epuletid}): {szolgaltatas.havi_koltseg} Ft")

def listaz_epuletek_es_szolgaltatasok():
    """Épületek és szolgáltatások listázása."""
    if not epuletek:
        print("\nNincsenek megépült épületek.")
    else:
        print("\nMegépült épületek:")
        for epulet in epuletek:
            print(f"- {epulet.nev} (Típus: {epulet.tipus}, Terület: {epulet.terulet} m², Állapot: {epulet.allapot}/5)")

    if not szolgaltatasok:
        print("\nNincsenek folyamatban lévő szolgáltatások.")
    else:
        print("\nFolyamatban lévő szolgáltatások:")
        for szolgaltatas in szolgaltatasok:
            print(f"- {szolgaltatas.nev} (Épület ID: {szolgaltatas.epuletid}, Havi költség: {szolgaltatas.havi_koltseg} Ft)")

    if not projektek:
        print("\nNincsenek folyamatban lévő projektek.")
    else:
        print("\nFolyamatban lévő projektek:")
        for projekt in projektek:
            print(f"- {projekt.nev} (Kezdő dátum: {projekt.kezdo_d.strftime('%Y.%m.%d')}, "
                  f"Befejező dátum: {projekt.befejezo_d.strftime('%Y.%m.%d')}, Típus: {projekt.tipus})")

esemenyek = [
    {"nev": "Nem történt semmi", "valoszinuseg": 0.5, "penzvaltozas": 0, "elegedettsegvaltozas": 0},
    {"nev": "Gazdasági fellendülés", "valoszinuseg": 0.2, "penzvaltozas": 10000, "elegedettsegvaltozas": 5},
    {"nev": "Természeti katasztrófa", "valoszinuseg": 0.1, "penzvaltozas": -20000, "elegedettsegvaltozas": -10},
    {"nev": "Lakossági tüntetés", "valoszinuseg": 0.1, "penzvaltozas": -5000, "elegedettsegvaltozas": -5},
    {"nev": "Új befektető érkezett", "valoszinuseg": 0.1, "penzvaltozas": 15000, "elegedettsegvaltozas": 10},
]

def varatlan_esemeny():
    """Váratlan esemény generálása."""
    esemeny = random.choices(esemenyek, weights=[e["valoszinuseg"] for e in esemenyek])[0]
    print(f"\nVáratlan esemény történt: {esemeny['nev']}")
    print(f"- Pénzváltozás: {'+' if esemeny['penzvaltozas'] > 0 else ''}{esemeny['penzvaltozas']} Ft")
    print(f"- Elégedettségváltozás: {'+' if esemeny['elegedettsegvaltozas'] > 0 else ''}{esemeny['elegedettsegvaltozas']}%")
    return esemeny["penzvaltozas"], esemeny["elegedettsegvaltozas"]

def levon_szolgaltatas_koltsegek(penzkeret):
    """Szolgáltatások havi költségeinek levonása."""
    osszes_havi_koltseg = 0
    for szolgaltatas in szolgaltatasok:
        osszes_havi_koltseg += szolgaltatas.havi_koltseg
    penzkeret -= osszes_havi_koltseg
    print(f"Összes szolgáltatási költség: {osszes_havi_koltseg} Ft")
    return penzkeret, osszes_havi_koltseg

def allami_tamogatas(penzkeret):
    """Állami támogatás hozzáadása."""
    tamogatas = 10000
    penzkeret += tamogatas
    print(f"\nÁllami támogatás érkezett: +{tamogatas} Ft")
    return penzkeret, tamogatas

lakossag = 0 # Itt definiáljuk a lakosságot

def projekt_befejezese(projekt, penzkeret, elegedettseg):
    """Projekt befejezése."""
    global epuletek, lakossag
    if "karbantartás" in projekt.nev.lower():
        epulet_nev = projekt.nev.replace("Karbantartás - ", "").strip()
        for epulet in epuletek:
            if epulet.nev.strip() == epulet_nev:
                epulet.allapot = 5
                print(f"Karbantartás befejeződött: {epulet.nev}. Új állapot: {epulet.allapot}/5.")
                return penzkeret, elegedettseg, 0
        print("Hiba: Nem található az épület a karbantartási projekthez.")
        return penzkeret, elegedettseg, 0
    else:
        uj_epulet = Epulet(f"{len(epuletek) + 1};{projekt.nev};{projekt.tipus};"
                                    f"{projekt.befejezo_d.strftime('%Y.%m.%d')};{projekt.terulet};5")
        epuletek.append(uj_epulet)

        lakossag_valtozas = 0
        if projekt.tipus and projekt.tipus.lower() == "lakóház":
            if uj_epulet.terulet > 0:
                lakossag_valtozas = uj_epulet.terulet / 30  # Lebegőpontos osztás
                lakossag += int(lakossag_valtozas)  # Egész számra kerekítés
                print(f"Lakóház épült: {uj_epulet.nev}. Lakosság növekedett: +{int(lakossag_valtozas)} fő (Új lakosság: {lakossag}).")
            else:
                print(f"Hiba: Az épület területe érvénytelen ({uj_epulet.terulet} m²).")

        elegedettseg += 10
        print(f"Projekt befejeződött: {projekt.nev}. Az épület elkészült!")
        return penzkeret, elegedettseg, lakossag_valtozas

def bekert_datum(prompt):
    """Dátum bekérése."""
    while True:
        datum = input(prompt)
        try:
            return datetime.strptime(datum, "%Y.%m.%d")
        except ValueError:
            print("Hiba: A dátum formátuma helytelen. Kérjük, adja meg a dátumot a következő formátumban: ÉÉÉÉ.MM.DD")

def fordulo(penzkeret, elegedettseg, min_elegedettseg, honapok_szama):
    """Játék forduló."""
    global lakossag
    aktualis_datum = datetime.now()
    for honap in range(1, honapok_szama + 1):
        print("\n" + "-" * 50)
        print(f"{honap}. hónap ({aktualis_datum.strftime('%Y.%m.%d')}):")
        print("-" * 50)
        print(f"Jelenlegi pénzkeret: {penzkeret} Ft, elégedettség: {elegedettseg}%")

        projekt_koltseg = 0
        for projekt in projektek:
            projekt_hossza_honapokban = max(1, (projekt.befejezo_d - projekt.kezdo_d).days // 30)
            havi_koltseg = projekt.koltseg // projekt_hossza_honapokban
            projekt_koltseg += havi_koltseg
            print(f"Projekt folyamatban: {projekt.nev}, havi költség: {havi_koltseg} Ft")

        penzkeret -= projekt_koltseg
        print(f"Folyamatban lévő projektek havi költsége: {projekt_koltseg} Ft")

        lakossag_valtozas = 0
        for projekt in projektek[:]:
            if projekt.befejezo_d <= aktualis_datum:
                print(f"Projekt elkészült: {projekt.nev}")
                penzkeret, elegedettseg, lakossag_valtozas = projekt_befejezese(projekt, penzkeret, elegedettseg)
                projektek.remove(projekt)

        # Események és állapotok tárolása
        esemenyek = []
        allapotok = []

        while True:
            print("\nVálasszon az alábbi lehetőségek közül:")
            print("1. Új épület építése")
            print("2. Karbantartás meglévő épületeken")
            print("3. Új szolgáltatás bevezetése")
            print("4. Szolgáltatás megszüntetése")
            print("5. Tovább a következő hónapra")
            print("6. Megépült épületek, szolgáltatások és folyamatban lévő projektek megtekintése")

            valasztas = input("Adja meg a választott opció számát: ")

            if valasztas == "1":
                projekt_nev = input("Adja meg az épület nevét: ")
                koltseg = int(input("Adja meg a projekt költségét: "))
                idotartam_honap = int(input("Adja meg a projekt időtartamát hónapokban: "))
                tipus = input("Adja meg az épület típusát (pl. lakóház): ")
                terulet = int(input("Adja meg az épület területét (m²): "))
                uj_projekt = uj_epulet_epitese(projekt_nev, koltseg, idotartam_honap, tipus, terulet, aktualis_datum)
                esemenyek.append(f"Új projekt indult: {projekt_nev}, költség: {koltseg}, típus: {tipus}, terület: {terulet} m².")
                break

            elif valasztas == "2":
                if not epuletek:
                    print("Nincsenek karbantartandó épületek.")
                    break

                print("\nElérhető épületek karbantartásra:")
                for epulet in epuletek:
                    print(f"ID: {epulet.azonosito}, Név: {epulet.nev}, Típus: {epulet.tipus}, "
                          f"Terület: {epulet.terulet} m², Állapot: {epulet.allapot}/5")

                try:
                    epulet_id = int(input("Adja meg a karbantartandó épület ID-jét: "))
                    epulet = next((e for e in epuletek if e.azonosito == epulet_id), None)
                    if not epulet:
                        print("Hiba: Nem található az épület azonosító alapján.")
                        break

                    javitasi_pont = 5 - epulet.allapot
                    if javitasi_pont <= 0:
                        print(f"Az épület ({epulet.nev}) már maximális állapotban van.")
                        break

                    koltseg = javitasi_pont * 5000
                    idotartam_honap = javitasi_pont
                    print(f"A karbantartás költsége: {koltseg} Ft, időtartama: {idotartam_honap} hónap.")

                    kezdo_datum = aktualis_datum
                    befejezo_datum = kezdo_datum + relativedelta(months=idotartam_honap)
                    uj_azonosito = len(projektek) + 1
                    projekt = Projekt(f"{uj_azonosito};Karbantartás - {epulet.nev};{koltseg};"
                                        f"{kezdo_datum.strftime('%Y.%m.%d')};{befejezo_datum.strftime('%Y.%m.%d')};karbantartás")
                    projektek.append(projekt)

                    print(f"Karbantartási projekt indult: {epulet.nev}, költség: {koltseg} Ft, "
                          f"várható befejezés: {befejezo_datum.strftime('%Y.%m.%d')}.")

                    penzkeret -= koltseg
                    esemenyek.append(f"Karbantartási projekt indult: {epulet.nev}, költség: {koltseg} Ft.")
                    break

                except ValueError:
                    print("Hiba: Érvénytelen azonosító.")

            elif valasztas == "3":
                nev = input("Adja meg a szolgáltatás nevét: ")
                epuletid = int(input("Adja meg az épület azonosítóját, ahol a szolgáltatás elérhető lesz: "))
                havi_koltseg = int(input("Adja meg a szolgáltatás havi költségét: "))
                elegedettseg = uj_szolgaltatas_bevezetese(nev, epuletid, havi_koltseg, elegedettseg)
                esemenyek.append(f"Új szolgáltatás bevezetve: {nev}, típus: {tipus}, havi költség: {havi_koltseg} Ft.")
                break

            elif valasztas == "4":
                elegedettseg = szolgaltatas_megszuntetese(elegedettseg)
                esemenyek.append(f"Szolgáltatás megszüntetve.")
                break

            elif valasztas == "5":
                print("Tovább a következő hónapra...")
                break

            elif valasztas == "6":
                listaz_epuletek_es_szolgaltatasok()

            else:
                print("Érvénytelen választás, próbálja újra!")

        penzkeret, szolgaltatas_koltseg = levon_szolgaltatas_koltsegek(penzkeret)
        penzvaltozas, elegedettsegvaltozas = varatlan_esemeny()
        penzkeret += penzvaltozas
        elegedettseg += elegedettsegvaltozas
        penzkeret, tamogatas = allami_tamogatas(penzkeret)

        # Állapotok tárolása
        allapotok.append(f"Pénzkeret: {penzkeret} Ft, Elégedettség: {elegedettseg}%, Lakosság: {lakossag} fő")
        for epulet in epuletek:
            allapotok.append(f"Épület: {epulet.nev}, Állapot: {epulet.allapot}/5")

        # Események és állapotok mentése fájlba
        with open("jatek_log.txt", "a", encoding="utf-8") as f:
            f.write(f"\n{honap}. hónap ({aktualis_datum.strftime('%Y.%m.%d')}):\n")
            for esemeny in esemenyek:
                f.write(f"- {esemeny}\n")
            for allapot in allapotok:
                f.write(f"- {allapot}\n")

        if penzkeret <= 0:
            print("A pénzkeret elfogyott. A játék véget ért.")
            break
        if elegedettseg < min_elegedettseg:
            print("A lakosok elégedettsége az elvárt szint alá esett. A játék véget ért.")
            break

        penzkeret_valtozas = penzvaltozas - szolgaltatas_koltseg - projekt_koltseg + tamogatas
        print("\nHónap végi összegzés:")
        print(f"- Szolgáltatások havi költsége: {szolgaltatas_koltseg} Ft")
        print(f"- Projektek havi költsége: {projekt_koltseg} Ft")
        print(f"- Pénzkeret változása: {'+' if penzkeret_valtozas > 0 else ''}{penzkeret_valtozas} Ft")
        print(f"- Elégedettség változása: {'+' if elegedettsegvaltozas > 0 else ''}{elegedettsegvaltozas}%")
        if lakossag_valtozas != 0:
            print(f"- Lakosság változása: {'+' if lakossag_valtozas > 0 else ''}{lakossag_valtozas} fő")
        print(f"- Hónap végi lakosság: {lakossag} fő")

        aktualis_datum += timedelta(days=30)

if __name__ == "__main__":
    penzkeret = 1000000
    elegedettseg = 50
    min_elegedettseg = 20
    honapok_szama = 12

    fordulo(penzkeret, elegedettseg, min_elegedettseg, honapok_szama)