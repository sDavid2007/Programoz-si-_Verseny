CSAPAT NEVE: Frappáns Joystick

CSAPATTAGOK NEVE:
	- Simkó János Dávid
	- Szilvási Mátyás
	- Pál Roland

ISKOLA NEVE: Debreceni SZC Mechwart András Gépipari és Informatikai Technikum

FELKÉSZÍTŐ TANÁR NEVE: Kertész János Andrásné

ELÉRHETŐSÉG: matyi200706@gmail.com